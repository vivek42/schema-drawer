import sqlite3
import subprocess as sub

# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #conn = sqlite3.connect('/Users/vivekchouhan/sqliteDb/schemaDrawer.db');
    database_install_file = filename
    database_deploy_dir = '/usr/local/'
    database_dir = 'sqlite'
    
    print "deleting existing database installation if it exists"
    p= sub.Popen(['rm', 'rf', database_deploy_dir + database_dir], stdout=sub.PIPE, stderr=sub.PIPE)
    out,err=p.communicate()
    if err:
        print err
    
    print "creating new database installation directory"
    p= sub.Popen(['mkdir', '-p', database_deploy_dir + database_dir], stdout=sub.PIPE, stderr=sub.PIPE)
    out,err=p.communicate()
    if err:
        print err
        print "Cannot create database installation directory, hence exiting"
        return

    print "Installing database now ..."
    p= sub.Popen(['cp',database_install_file, database_deploy_dir + database_dir], stdout=sub.PIPE, stderr=sub.PIPE)
    out,err=p.communicate()

conn = sqlite3.connect(database_deploy_dir + database_dir + database_install_file);
    
    print "opened connection successfully"
    
    conn.close
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    tomcat_installation_tar = "apache-tomcat-7.0.68.tar.gz"
    tomcat_installation_dir = "apache-tomcat-7.0.68"
    tomcat_dir = "tomcat7"
    tomcat_deploy_dir = "/usr/local/"
    java_home = "/usr/lib/jvm/java-1.7.0-openjdk-amd64"
    jre_home = "/usr/lib/jvm/java-1.7.0-openjdk-amd64"
    user_config_xml = tomcat_installation_dir + "/conf/tomcat-users.xml"
    catalina = tomcat_installation_dir + "/bin/catalina.sh"
    
    print "deleting existing tomcat installation if it exists"
    p= sub.Popen(['rm', 'rf', tomcat_deploy_dir + tomcat_dir], stdout=sub.PIPE, stderr=sub.PIPE)
    out,err=p.communicate()
    if err:
        print err
    
    print "creating new tomcat installation directory"
    p= sub.Popen(['mkdir', '-p', tomcat_deploy_dir + tomcat_dir], stdout=sub.PIPE, stderr=sub.PIPE)
    out,err=p.communicate()
    if err:
        print err
        print "Cannot create tomcat installation directory, hence exiting"
        return
    
    print "Installing tomcat now ..."
    p= sub.Popen(['tar', '-xvf', tomcat_installation_tar], stdout=sub.PIPE, stderr=sub.PIPE)
    out,err=p.communicate()
    if err:
        print err
        print "Cannot untar tomcat installation files, hence exiting"
        return
    
    print "adding custom configuration to the tomcat installation"
    with open(catalina, 'a') as file:
        file.write("JAVA_HOME="+java_home)
        file.write("JRE_HOME="+jre_home)
    
    user_config_xml_contents = []

old_content = '</tomcat-users>'
    new_content = '''<!-- user admin can access manager and admin section both -->\n <role rolename="admin-gui"/>\n <user username="admin" password="ubuntu" roles="manager-gui,admin-gui"/>\n </tomcat-users>'''
    
    with open(user_config_xml, 'r') as file:
        for line in file.readlines():
            user_config_xml_contents.append(line.replace(old_content, new_content))

with open(user_config_xml, 'w') as file:
    for line in user_config_xml_contents:
        file.write(line)
    
    print "Moving tomcat installation directory under appropritate directory"
    p=sub.Popen(['mv', tomcat_installation_dir, tomcat_dir], stdout=sub.PIPE, stderr=sub.PIPE)
    p=sub.Popen(['mv', tomcat_dir, tomcat_deploy_dir + tomcat_dir], stdout=sub.PIPE, stderr=sub.PIPE)
    out,err=p.communicate()
    if err:
        print err
        print "exiting installation of tomcat"
        return
    
    print "Tomcat has been successfully deployed in the system"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
build_database(filename)
deploy_tomcat()
deploy_schema_drawer()
