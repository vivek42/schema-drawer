# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()
# This method will insert all the schema queries in the database
# It will take a sql file as an argument
def build_database(filename):
    #fo = open(filename, "r+")
    #str = fo.read(20)
    #print "we read this from file <", filename, "> :", str
    #fo.close()
    print "Database build is successful"


# This method will install tomcat from the installation tar file into the system
# TODO : Deploy tomcat
def deploy_tomcat():
    print "Tomcat has been successfully deployed in the system"

# This method will check the status of tomcat application and database
# TODO: check statuses
def check_tomcat_database():
    print "Tomcat and database is up and running"

# This method will deploy the schema drawer along with tomcat
# TODO: check statuses
def deploy_schema_drawer():
    print "Schema Drawer has been successfully deployed"


filename = ""
deploy_tomcat()
check_tomcat_database()
build_database(filename)
deploy_schema_drawer()

